import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
// import Title from './Title';

class SearchBar extends Component {
    constructor(props) {
        super(props)
        this.state = {
            inputValue: ""
        }
    }
    handleChange = (e) => {
        this.setState({
            inputValue: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault()
        this.props.onSubmittedSearch(this.state.inputValue)
    }

    render() {
        //{this.props.onSubmittedSearch(this.state.inputValue)} 
        return (
            <section>
                <form onSubmit={this.handleSubmit}>
                    <label htmlFor="searching">
                    {/* <Title>News Search</Title> */}
                    <input type="text" value={this.state.inputValue} onChange={this.handleChange} /></label>
                    <Button variant="contained" color="primary" type="submit" value="Submit">Search</Button>
                </form>

            </section>
        )
    }

}

export default SearchBar