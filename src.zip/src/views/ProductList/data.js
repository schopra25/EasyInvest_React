import uuid from 'uuid/v1';

export default [
  {
    id: uuid(),
    title: 'Stocks',
    description:
      'Classic investing product: Own shares in a company and have an pportunity for dividend income.',
    imageUrl: '/images/products/product_1.png',
    totalDownloads: '594',
    updatedAt: '27/03/2019'
  },
  {
    id: uuid(),
    title: 'ETFs',
    description:
      'Exhange traded funds: Track specific industries or indices.',
    imageUrl: '/images/products/product_2.png',
    totalDownloads: '625',
    createdAt: '31/03/2019'
  },
  {
    id: uuid(),
    title: 'Options',
    description:
      'Contract to buy or sell: Potential to generate income on stock holdings.',
    imageUrl: '/images/products/product_3.png',
    totalDownloads: '857',
    createdAt: '03/04/2019'
  },
  {
    id: uuid(),
    title: 'IPOS',
    description:
      'Initial public offering: Own a company before it hits the broader market.',
    imageUrl: '/images/products/product_4.png',
    totalDownloads: '406',
    createdAt: '04/04/2019'
  },
  {
    id: uuid(),
    title: 'Mutual Funds',
    description:
      'Choose from thousands of funds to diversify your investments.',
    imageUrl: '/images/products/product_1.png',
    totalDownloads: '835',
    createdAt: '04/04/2019'
  },
  {
    id: uuid(),
    title: 'Bonds',
    description:
      'Minimize the ups and downs of the markets with bonds.',
    imageUrl: '/images/products/product_2.png',
    totalDownloads: '835',
    createdAt: '04/04/2019'
  }
];
