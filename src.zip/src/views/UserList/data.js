import uuid from 'uuid/v1';

export default [
  {
    id: uuid(),
    name: 'MCD',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$112',
      // street: '2849 Fulton Street'
    },
    email: 'Sell',
    phone: '45',
    avatarUrl: '/images/avatars/avatar_1.png',
    createdAt: 1555016400000
  },
  {
    id: uuid(),
    name: 'TRST.TO',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$1.45',
      // street: '2849 Fulton Street'
    },
    email: 'Sell',
    avatarUrl: '/images/avatars/avatar_2.png',
    phone: '71',
    createdAt: 1555016400000
  },
  {
    id: uuid(),
    name: 'WN.TO',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$56',
      // street: '2849 Fulton Street'
    },
    email: 'Buy',
    phone: '7',
    avatarUrl: '/images/avatars/avatar_3.png',
    createdAt: 1555016400000
  },
  {
    id: uuid(),
    name: 'ACHV',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$45',
      // street: '2849 Fulton Street'
    },
    email: 'Sell',
    avatarUrl: '/images/avatars/avatar_4.png',
    phone: '12',
    createdAt: 1554930000000
  },
  {
    id: uuid(),
    name: 'ENB',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$75',
      // street: '2849 Fulton Street'
    },
    email: 'Sell',
    phone: '96',
    avatarUrl: '/images/avatars/avatar_6.png',
    createdAt: 1554757200000
  },
  {
    id: uuid(),
    name: 'FB',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$195',
      // street: '2849 Fulton Street'
    },
    email: 'Buy',
    phone: '85',
    avatarUrl: '/images/avatars/avatar_5.png',
    createdAt: 1554670800000
  },
  {
    id: uuid(),
    name: 'MCD',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$114',
      // street: '2849 Fulton Street'
    },
    email: 'Buy',
    avatarUrl: '/images/avatars/avatar_1.png',
    phone: '47',
    createdAt: 1554325200000
  },
  {
    id: uuid(),
    name: 'FB',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$192',
      // street: '2849 Fulton Street'
    },
    email: 'Buy',
    phone: '54',
    avatarUrl: '/images/avatars/avatar_5.png',
    createdAt: 1523048400000
  },
  {
    id: uuid(),
    name: 'LUV',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$124',
      // street: '2849 Fulton Street'
    },
    email: 'Buy',
    avatarUrl: '/images/avatars/avatar_7.png',
    phone: '37'
  },
  {
    id: uuid(),
    name: 'LUV',
    address: {
      // country: '$112',
      // state: 'West Virginia',
      city: '$128',
      // street: '2849 Fulton Street'
    },
    email: 'Sell',
    phone: '84',
    avatarUrl: '/images/avatars/avatar_7.png',
    createdAt: 1522702800000
  }
];
