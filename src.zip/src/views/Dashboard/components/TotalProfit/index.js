export { default } from './TotalProfit';
