import uuid from 'uuid/v1';

export default [
  {
    id: uuid(),
    ref: 'MCD',
    amount: 30.5,
    fillprice: '$112',
    customer: {
      name: 'Sell'
    },
    createdAt: 1555016400000,
    status: '45'
  },
  {
    id: uuid(),
    ref: 'TRST.TO',
    amount: 25.1,
    fillprice: '$1.45',
    customer: {
      name: 'Sell'
    },
    createdAt: 1555016400000,
    status: '10'
  },
  {
    id: uuid(),
    ref: 'WN.TO',
    amount: 10.99,
    fillprice: '$56',
    customer: {
      name: 'Sell'
    },
    createdAt: 1554930000000,
    status: '15'
  },
  {
    id: uuid(),
    ref: 'ACHV',
    amount: 96.43,
    fillprice: '$45',
    customer: {
      name: 'Buy'
    },
    createdAt: 1554757200000,
    status: '100'
  },
  {
    id: uuid(),
    ref: 'ENB',
    amount: 32.54,
    fillprice: '$75',
    customer: {
      name: 'Sell'
    },
    createdAt: 1554670800000,
    status: '40'
  },
  {
    id: uuid(),
    ref: 'FB',
    amount: 16.76,
    fillprice: '$195',
    customer: {
      name: 'Buy'
    },
    createdAt: 1554670800000,
    status: 'Buy'
  }
];
