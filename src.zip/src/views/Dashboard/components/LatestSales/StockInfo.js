import React from 'react';
import axios from 'axios';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

//Class component since stock information will change and therefore requires a state
//Props for passing information from parent to child regarding user input
class StockInfo extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            stocks: [],
            isLoading: false,
        }
    }

    componentDidUpdate(prevProps) {
        if (prevProps.inputValue !== this.props.inputValue) {
          this.fetchData();
        }
      }

    //This maps through the array of API data and displays it's information on the page one by one
    renderStockInfo() {
        const stockList = this.state.stocks.map((stock) =>{
            console.log(stock)
            return(
                //Need to pass in index as the list in this case won't be changing

                <Table>
                <TableHead>
                  <TableRow>
                  <TableCell><p>{stock['01. symbol']}</p></TableCell>
                    {/* <TableCell>Action</TableCell>
                    <TableCell>Quantity</TableCell>
                    <TableCell>Order Type</TableCell>
                    <TableCell>Fill Price</TableCell> */}
                  </TableRow>
                </TableHead>
                <TableBody>
                    <TableRow>
                    <div key={stock}>
                      <TableCell><p>Open: {stock['02. open']}</p></TableCell>
                      <TableCell><p>High: {stock['03. high']}</p></TableCell>
                      <TableCell><p>Low: {stock['04. low']}</p></TableCell>
                      <TableCell><p>Price: {stock['05. price']}</p></TableCell>
                      <TableCell><Button variant="contained" color="primary" value="Buy" onClick={Buy}>Buy</Button></TableCell>
                      <TableCell><Button variant="contained" color="primary" value="Sell">Sell</Button></TableCell>
                      <TableCell><Button variant="contained" color="primary" value="Watchlist">Watchlist</Button></TableCell>
                      </div>
                    </TableRow>
                </TableBody>
              </Table>      
                
            )
        })
        return(
            <div>
                {stockList}
            </div>
        )
    }
    
    //Render an empty state if fetching of information is slow
    renderEmptyState(){
        return (
            <p></p>
        )
    }   


    // //Fetching data from stock price API using axios
    async fetchData() {
        this.setState({ isLoading: true });
        try {
            const stockData = await axios.get('https://www.alphavantage.co/query', {
                params: {
                    function: 'GLOBAL_QUOTE',
                    symbol: this.props.inputValue,
                    apikey: 'Q5P27AJF5YBX8GEE' 
                }
            })
            //The data received from API is an object. To make use of the map method above and simplicity's sake, converting it from object to array using Object.values
            this.setState({ isLoading: false });
            console.log(stockData);
            const info = stockData.data
            const tradeInfo = Object.values(info)
            this.setState({
                stocks: tradeInfo
            })
        } catch (error) {
            console.log(error);
        }
       console.log(this.state.stocks)
       console.log(this.state.stocks.length)
    }
    
    //Conditional rendering. If there are no stocks in the state, render a loading message. If there are, display the stock information
    render() {
        return(
            <section>
            {this.state.stocks.length > 0 ? this.renderStockInfo() : this.renderEmptyState()}
            {this.state.isLoading && 'Loading...'}
            {/* <Typography component="p" variant="h4" className="Invested">
        $19,036.75
      </Typography> */}
            </section>
            
        )
    }

}

let counter = 0;

function Buy() {
      console.log('The link was clicked.');
    //   counter = counter + 1;      
    //   $('.Invested').text(counter);  
    }
export default StockInfo;
