import React from 'react';
import Button from '@material-ui/core/Button';

class UserInput extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            inputValue: ""
        }
    }

    //Change handler ensures the value is being updated as user inputs keywords in input field
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    render() {
        return(
            <form onSubmit={(e) => this.props.handleSubmit(e, this.state.inputValue)}>
                <label>
                    Enter stock symbol: 
                    <input type="text" value={this.state.inputValue} name='inputValue' onChange={this.handleChange}/>
                    <Button variant="contained" color="primary" type="submit" value="Submit">Submit</Button>
                    {/* <input type="submit" value="Submit" /> */}
                </label>
            </form>
        )
    }


}

export default UserInput;