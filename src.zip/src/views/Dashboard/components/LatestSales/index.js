export { default } from './LatestSales';
